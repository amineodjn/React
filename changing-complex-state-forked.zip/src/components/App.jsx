import React, { useState } from "react";

function App() {
  const [FullNAme, setFullName] = useState({
    fName: "",
    lName: ""
  });

  function HandleChange(event) {
    const { value, name } = event.target;

    setFullName((PrevValue) => {
      if (name === "fName") {
        return {
          fName: value,
          lName: PrevValue.lName
        };
      } else if (name === "lName") {
        return {
          fName: PrevValue.fName,
          lName: value
        };
      }
    });
  }

  return (
    <div className="container">
      <h1>
        Hello {FullNAme.fName} {FullNAme.lName}
      </h1>
      <form>
        <input
          name="fName"
          onChange={HandleChange}
          placeholder="First Name"
          value={FullNAme.fName}
        />
        <input
          name="lName"
          onChange={HandleChange}
          placeholder="Last Name"
          value={FullNAme.lName}
        />
        <button>Submit</button>
      </form>
    </div>
  );
}

export default App;
