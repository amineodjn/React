import React from "react";
import Heading from "./Heading";

function app() {
  return <Heading />;
}

export default app;
