import React, { useState } from "react";

function App() {
  const [toDo, setToDo] = useState("");
  const [List, setList] = useState([]);
  function changeHandler(event) {
    const value = event.target.value;
    setToDo(value);
  }
  const handleClick = (event) => {
    setList((preValue) => [...preValue, toDo]);
    setToDo(" ");
  };

  return (
    <div className="container">
      <div className="heading">
        <h1>To-Do List</h1>
      </div>
      <div className="form">
        <input onChange={changeHandler} type="text" value={toDo} />
        <button onClick={handleClick}>
          <span>Add</span>
        </button>
      </div>
      <div>
        {List.map((newValue, index) => {
          return (
            <div key={index}>
              <li>{newValue}</li>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default App;
