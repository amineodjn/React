import React from "react";
import ReactDOM from "react-dom";

const MyName = "Amine Oudjana";
var year = new Date().getFullYear();

ReactDOM.render(
  <div>
    <h1 className="heading">Most common programming languages </h1>
    <div>
      <img
        className="pic-img"
        src="https://www.w3schools.com/whatis/img_html.jpg"
      />
      <img
        className="pic-img"
        src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/CSS3_logo_and_wordmark.svg/1200px-CSS3_logo_and_wordmark.svg.png"
      />
      <img
        className="pic-img"
        src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Unofficial_JavaScript_logo_2.svg/1200px-Unofficial_JavaScript_logo_2.svg.png"
      />
    </div>
  </div>,
  document.getElementById("root")
);
