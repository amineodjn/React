import React from "react";
import Card from "./Card";

function App() {
  return (
    <div classname="body ">
      <Card
        name="Beyonce"
        imgURL="https://nationaltoday.com/wp-content/uploads/2020/09/Beyonce%CC%81s-Birthday.jpg"
        phone="+1 2434546"
        email="beyonce@damn.music"
      />
    </div>
  );
}

export default App;
