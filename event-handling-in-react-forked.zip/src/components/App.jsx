import React, { useState } from "react";

function App() {
  const [isMouseOver, SetMouseOver] = useState(false);

  function onmouseOver() {
    SetMouseOver(true);
  }
  function onmouseOut() {
    SetMouseOver(false);
  }

  return (
    <div className="container">
      <h1>Hello</h1>
      <input type="text" placeholder="What's your name?" />
      <button
        style={{ backgroundColor: isMouseOver ? "black" : "white" }}
        onMouseOver={onmouseOver}
        onMouseOut={onmouseOut}
      >
        Submit
      </button>
    </div>
  );
}

export default App;
