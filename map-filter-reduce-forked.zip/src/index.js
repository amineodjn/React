import emojipedia from "./emojipedia";
var numbers = [3, 56, 2, 48, 5];

//Map -Create a new array by doing something with each item in an array.
const newNumber = numbers.map(function (x) {
  return x * 2;
});
console.log(newNumber);
//Filter - Create a new array by keeping the items that return true.
const Number = numbers.filter(function (num) {
  return num > 10;
});
console.log(Number);

//Reduce - Accumulate a value by doing something to each itm in an array.
const degit = numbers.reduce(function (accumulator, currentNumber) {
  return accumulator + currentNumber;
});
console.log(degit);
//Find - find the first item that matches from an array.
const currentX = numbers.find(function (xx) {
  return xx > 10;
});
console.log(currentX);

//FindIndex - find the index of the first item that matches.
const current = numbers.findIndex(function (number) {
  return number > 10;
});
console.log(current);

const myArray = emojipedia.map(function (x) {
  return x.meaning.substring(0, 100);
});
console.log(myArray);
