const animals = [
  {
    name: "cat",
    sound: "meow",
    foodRequirements: {
      food: 2,
      water: 3
    }
  },
  { name: "dog", sound: "woof" }
];

export default animals;
