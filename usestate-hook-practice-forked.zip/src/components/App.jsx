import React, { useState } from "react";

function App() {
  setInterval(NewTime, 1000);

  const now = new Date().toLocaleTimeString();

  const [currentTime, setTime] = useState(now);

  function NewTime() {
    const timeNow = new Date().toLocaleTimeString();
    setTime(timeNow);
  }

  return (
    <div className="container">
      <h1>{currentTime}</h1>
      <button onClick={NewTime}>Get Time</button>
    </div>
  );
}

export default App;
