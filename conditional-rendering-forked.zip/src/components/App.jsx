import React from "react";
import Login from "./login";

const currenTime = new Date().getHours();
var isLoggedin = false;

function renderConditionally() {}

function App() {
  return (
    <div className="container">
      {isLoggedin === true ? <h1>Hello</h1> : <Login />}
      {/* // currenTime>9 && <h1>Hello</h1>} */}
      {}
    </div>
  );
}

export default App;
